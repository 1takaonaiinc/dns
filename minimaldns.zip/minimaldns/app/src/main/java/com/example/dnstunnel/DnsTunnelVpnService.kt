// File: app/src/main/java/com/example/dnstunnel/DnsTunnelVpnService.kt
package com.example.dnstunnel

import android.content.Intent
import android.net.VpnService
import android.net.VpnService.Builder
import android.os.ParcelFileDescriptor

/**
 * DnsTunnelVpnService sets up a minimal VPN interface to tunnel DNS queries.
 */
class DnsTunnelVpnService : VpnService() {

    private var vpnInterface: ParcelFileDescriptor? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Retrieve the DNS address from the intent; default to 8.8.8.8 if not provided.
        val dns = intent?.getStringExtra("DNS_ADDRESS") ?: "8.8.8.8"

        // Build the VPN interface
        val builder = Builder()
        builder.setSession("Minimal DNS Tunnel")
            .setMtu(1500)
            .addAddress("10.0.0.2", 32)    // Dummy IP for the VPN interface
            .addRoute("0.0.0.0", 0)         // Default route
            .addDnsServer(dns)              // Use the specified DNS server

        // Establish the VPN interface
        vpnInterface = builder.establish()

        // Return START_STICKY so the service is restarted if the system kills it.
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        // Properly close the VPN interface to conserve battery.
        vpnInterface?.close()
        vpnInterface = null
    }
}
