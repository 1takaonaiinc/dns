// File: app/src/main/java/com/example/dnstunnel/MainActivity.kt
package com.example.dnstunnel

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

/**
 * MainActivity provides a simple UI to start and stop the VPN service.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var dnsInput: EditText
    private lateinit var startButton: Button
    private lateinit var stopButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        dnsInput = findViewById(R.id.dnsInput)
        startButton = findViewById(R.id.startButton)
        stopButton = findViewById(R.id.stopButton)

        startButton.setOnClickListener {
            // Use user-provided DNS or default to 8.8.8.8
            val dns = dnsInput.text.toString().ifEmpty { "8.8.8.8" }

            // Prepare the VPN (this will show a permission dialog if needed)
            val prepareIntent = VpnService.prepare(this)
            if (prepareIntent != null) {
                startActivityForResult(prepareIntent, 0)
            } else {
                onActivityResult(0, Activity.RESULT_OK, null)
            }

            // Start the VPN service with the DNS address
            val serviceIntent = Intent(this, DnsTunnelVpnService::class.java)
            serviceIntent.putExtra("DNS_ADDRESS", dns)
            startService(serviceIntent)
        }

        stopButton.setOnClickListener {
            // Stop the VPN service
            stopService(Intent(this, DnsTunnelVpnService::class.java))
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == 0 && resultCode == Activity.RESULT_OK) {
            // Permission granted; service is already started in the click listener.
        }
        super.onActivityResult(requestCode, resultCode, data)
    }
}
